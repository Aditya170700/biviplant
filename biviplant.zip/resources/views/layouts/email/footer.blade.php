<div class="footer">
    CopyRight &copy; <a href="https://biviplant.com">Biviplant</a> {{ date('Y') }} - All Rights
    Reserved
</div>
