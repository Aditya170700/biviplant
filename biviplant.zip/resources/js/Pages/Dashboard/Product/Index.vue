<template>
    <Layout
        :title="'Produk'"
        :typeButton="'create'"
        :href="route('admin.products.create')"
    >
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-start">
                            <div class="col-lg-2 col-sm-6 me-2">
                                <div class="mb-3">
                                    <input
                                        class="form-control"
                                        placeholder="Cari..."
                                        v-model="params.search"
                                    />
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-6 me-2">
                                <select
                                    class="form-control mb-3"
                                    v-model="params.limit"
                                >
                                    <option value="25">Lihat 25 data</option>
                                    <option value="50">Lihat 50 data</option>
                                    <option value="100">Lihat 100 data</option>
                                    <option value="200">Lihat 200 data</option>
                                </select>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="table-dark">
                                    <tr>
                                        <th>NO</th>
                                        <th>
                                            <span
                                                @click="sort('name')"
                                                class="d-flex justify-content-between"
                                                style="cursor: pointer"
                                            >
                                                NAMA
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'asc' &&
                                                        params.field == 'name'
                                                    "
                                                    class="fa-solid fa-arrow-down-a-z"
                                                ></i>
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'desc' &&
                                                        params.field == 'name'
                                                    "
                                                    class="fa-solid fa-arrow-up-z-a"
                                                ></i>
                                            </span>
                                        </th>
                                        <th>
                                            <span
                                                @click="sort('price')"
                                                class="d-flex justify-content-between"
                                                style="cursor: pointer"
                                            >
                                                HARGA
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'asc' &&
                                                        params.field == 'price'
                                                    "
                                                    class="fa-solid fa-arrow-down-a-z"
                                                ></i>
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'desc' &&
                                                        params.field == 'price'
                                                    "
                                                    class="fa-solid fa-arrow-up-z-a"
                                                ></i>
                                            </span>
                                        </th>
                                        <th>
                                            <span
                                                @click="sort('strike_price')"
                                                class="d-flex justify-content-between"
                                                style="cursor: pointer"
                                            >
                                                HARGA CORET
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'asc' &&
                                                        params.field ==
                                                            'strike_price'
                                                    "
                                                    class="fa-solid fa-arrow-down-a-z"
                                                ></i>
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'desc' &&
                                                        params.field ==
                                                            'strike_price'
                                                    "
                                                    class="fa-solid fa-arrow-up-z-a"
                                                ></i>
                                            </span>
                                        </th>
                                        <th>
                                            <span
                                                @click="sort('weight')"
                                                class="d-flex justify-content-between"
                                                style="cursor: pointer"
                                            >
                                                BERAT
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'asc' &&
                                                        params.field == 'weight'
                                                    "
                                                    class="fa-solid fa-arrow-down-a-z"
                                                ></i>
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'desc' &&
                                                        params.field == 'weight'
                                                    "
                                                    class="fa-solid fa-arrow-up-z-a"
                                                ></i>
                                            </span>
                                        </th>
                                        <th>
                                            <span
                                                @click="sort('stock')"
                                                class="d-flex justify-content-between"
                                                style="cursor: pointer"
                                            >
                                                STOK
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'asc' &&
                                                        params.field == 'stock'
                                                    "
                                                    class="fa-solid fa-arrow-down-a-z"
                                                ></i>
                                                <i
                                                    v-if="
                                                        params.direction ==
                                                            'desc' &&
                                                        params.field == 'stock'
                                                    "
                                                    class="fa-solid fa-arrow-up-z-a"
                                                ></i>
                                            </span>
                                        </th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="(result, i) in results.data"
                                        :key="i"
                                    >
                                        <td>{{ i + 1 }}</td>
                                        <td>{{ result.name }}</td>
                                        <td>{{ result.price_rp }}</td>
                                        <td>{{ result.strike_price_rp }}</td>
                                        <td>{{ result.weight }}gr</td>
                                        <td>{{ result.stock }}</td>
                                        <td class="d-flex justify-content-end">
                                            <Link
                                                :href="
                                                    route(
                                                        'admin.products.origins',
                                                        {
                                                            id: result.id,
                                                        }
                                                    )
                                                "
                                                class="btn btn-sm btn-success me-2 rounded-custom"
                                            >
                                                <i
                                                    class="fas fa-location-arrow"
                                                ></i>
                                            </Link>
                                            <Link
                                                :href="
                                                    route(
                                                        'admin.products.files',
                                                        {
                                                            id: result.id,
                                                        }
                                                    )
                                                "
                                                class="btn btn-sm btn-info me-2 rounded-custom"
                                            >
                                                <i class="fas fa-images"></i>
                                            </Link>
                                            <Link
                                                :href="
                                                    route(
                                                        'admin.products.show',
                                                        {
                                                            id: result.id,
                                                        }
                                                    )
                                                "
                                                class="btn btn-sm btn-primary me-2 rounded-custom"
                                            >
                                                <i class="fas fa-eye"></i>
                                            </Link>
                                            <Link
                                                :href="
                                                    route(
                                                        'admin.products.edit',
                                                        {
                                                            id: result.id,
                                                        }
                                                    )
                                                "
                                                class="btn btn-sm btn-warning me-2 rounded-custom"
                                            >
                                                <i class="fas fa-pencil"></i>
                                            </Link>
                                            <button
                                                class="btn btn-sm btn-danger me-2 rounded-custom"
                                                @click="destroy(result.id)"
                                            >
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <Pagination
                                class="mt-6"
                                :links="results.links"
                                :from="results.from"
                                :to="results.to"
                                :total="results.total"
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="modal fade"
            id="attachSuplier"
            tabindex="-1"
            aria-labelledby="attachSuplierLabel"
            aria-hidden="true"
        >
            <div class="modal-dialog modal-lg">
                <div class="modal-content rounded-custom">
                    <div class="modal-body">
                        <div
                            class="d-flex justify-content-between align-items-center mb-3"
                        >
                            <div class="h5">Pilih Suplier</div>
                        </div>
                        <div class="row"></div>
                    </div>
                </div>
            </div>
        </div>
    </Layout>
</template>

<script>
import Layout from "../../../Layouts/Dashboard/App.vue";
import Pagination from "../../../Shared/Pagination.vue";
import { Link } from "@inertiajs/inertia-vue3";
import { Inertia } from "@inertiajs/inertia";
import { reactive } from "vue";
import { pickBy } from "lodash";

export default {
    components: { Layout, Link, Pagination },
    props: {
        errors: Object,
        results: Object,
        filters: Object,
    },
    setup(props) {
        let params = reactive({
            search: props.filters.search,
            limit: props.filters.limit ?? 25,
            field: props.filters.field,
            direction: props.filters.direction,
        });

        let sort = (field) => {
            params.field = field;
            params.direction = params.direction == "asc" ? "desc" : "asc";
        };

        let destroy = (id) => {
            confirmation(
                "Tindakan ini akan menghapus data secara permanen"
            ).then((res) => {
                if (res) {
                    Inertia.delete(route("admin.products.destroy", { id: id }));
                }
            });
        };

        return {
            params,
            sort,
            destroy,
        };
    },
    watch: {
        params: {
            handler() {
                let params = pickBy(this.params);
                Inertia.get(route("admin.products.index"), params, {
                    replace: true,
                    preserveState: true,
                });
            },
            deep: true,
        },
    },
};
</script>
