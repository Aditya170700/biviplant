<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.email.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="header">
        <?php echo $__env->yieldContent('title'); ?>
    </div>
    <div class="body">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('layouts.email.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\USER\Documents\biviplant\biviplant\resources\views/layouts/email/app.blade.php ENDPATH**/ ?>