<div class="footer">
    CopyRight &copy; <a href="https://biviplant.com">Biviplant</a> <?php echo e(date('Y')); ?> - All Rights
    Reserved
</div>
<?php /**PATH C:\Users\USER\Documents\biviplant\biviplant\resources\views/layouts/email/footer.blade.php ENDPATH**/ ?>