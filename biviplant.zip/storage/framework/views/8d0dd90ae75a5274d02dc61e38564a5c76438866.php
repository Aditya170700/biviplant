

<?php $__env->startSection('title', 'Pesanan Baru'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-3">
        <div class="col-12">
            <p>Hai Min,</p>
            <p>
                pesanan atas nama <?php echo e($order->user->name); ?> sudah masuk. Jika pembayaran telah dilakukan, segera lakukan
                pengiriman.</p>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-12">
            <h2 class="fw-bold">RINCIAN PESANAN</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-3 fw-bold">Order ID</div>
        <div class="col-9 fw-light">: <?php echo e($order->payment_id); ?></div>
    </div>
    <div class="row">
        <div class="col-3 fw-bold">Order Date</div>
        <div class="col-9 fw-light">: <?php echo e(date('d/m/Y', strtotime($order->created_at))); ?></div>
    </div>
    <div class="row">
        <div class="col-3 fw-bold">Customer</div>
        <div class="col-9 fw-light">: <?php echo e($order->user->name); ?></div>
    </div>
    <div class="row">
        <div class="col-3 fw-bold">Produk</div>
        <div class="col-9 fw-light">: <?php echo e($order->order_details[0]->product->name); ?> <?php if($order->order_details->count() > 1): ?>
                dan <?php echo e($order->order_details->count() - 1); ?> produk lainnya
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-3 fw-bold">Metode Pembayaran</div>
        <div class="col-9 fw-light">: <?php echo e(strtoupper($order->payment_method)); ?></div>
    </div>
    <div class="row">
        <div class="col-3 fw-bold">Channel</div>
        <div class="col-9 fw-light">: <?php echo e(strtoupper($order->payment_channel)); ?></div>
    </div>
    <div class="row">
        <div class="col-3 fw-bold">Total</div>
        <div class="col-9 fw-light">: <?php echo e($order->total_rp); ?></div>
    </div>
    <div class="row mt-3">
        <div class="col-3">
            <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="btn btn-sm btn-success text-decoration-none"
                target="_blank">Lihat
                Pesanan</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.email.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\biviplant\biviplant\resources\views/email/admin/new-order.blade.php ENDPATH**/ ?>