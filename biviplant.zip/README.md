### BIVIPLANT

Requirements: - PHP 8.0+

Install dependency

`composer install`

`npm install`

Run the application

`php artisan serve`

`npm run watch`

`node public/js/ssr.js`

Sync Raja Ongkir

`php artisan sync:ro`
